<?php

return [
    'name' => 'Products',
];
