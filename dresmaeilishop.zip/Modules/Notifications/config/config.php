<?php

return [
    'name' => 'Notifications',
];
