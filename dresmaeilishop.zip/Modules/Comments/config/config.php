<?php

return [
    'name' => 'Comments',
];
